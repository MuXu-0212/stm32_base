
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LED' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STARTUP_STM32F4xx    /* Device Startup for STM32F4 */
#define RTE_DEVICE_STDPERIPH_EXTI
#define RTE_DEVICE_STDPERIPH_FRAMEWORK
#define RTE_DEVICE_STDPERIPH_GPIO
#define RTE_DEVICE_STDPERIPH_IWDG
#define RTE_DEVICE_STDPERIPH_PWR
#define RTE_DEVICE_STDPERIPH_RCC
#define RTE_DEVICE_STDPERIPH_RTC
#define RTE_DEVICE_STDPERIPH_SYSCFG
#define RTE_DEVICE_STDPERIPH_TIM
#define RTE_DEVICE_STDPERIPH_USART
#define RTE_DEVICE_STDPERIPH_WWDG

#endif /* RTE_COMPONENTS_H */
