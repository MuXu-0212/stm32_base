#include "sys.h"



static volatile uint32_t week_up_flag = 0;


int main(void)
{
	Usart1_Init(115200);
	LCD_Init();
	Rtc_Init();
	Rtc_Alarm_Set();
	
	while(1)
	{
		if(week_up_flag == 1)
		{
			Printf_Date();
			Printf_Time();
			week_up_flag = 0;
		}
	}
	return 0;

}


void RTC_WKUP_IRQHandler(void)
{
    if(RTC_GetITStatus(RTC_IT_WUT) != RESET)
    {
        printf("RTC_WKUP_IRQHandler\r\n");
		
		week_up_flag = 1;
		
        RTC_ClearITPendingBit(RTC_IT_WUT);
        EXTI_ClearITPendingBit(EXTI_Line22);
    } 
}



void RTC_Alarm_IRQHandler(void)
{
    if(RTC_GetITStatus(RTC_IT_ALRA) != RESET)
    {
        printf("RTC_Alarm_IRQHandler\r\n");
		
		PFout(9) = 0;
        RTC_ClearITPendingBit(RTC_IT_ALRA);
        EXTI_ClearITPendingBit(EXTI_Line17);
    } 
}

